package com.example.one;

import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.renderer.entity.PlayerRenderer;

/** Adds the hip sheath to the player model. Call from onInitializeClient(). */
public final class SheathRegistration {
    private SheathRegistration() {}

    public static void register() {
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((entityType, renderer, helper, context) -> {
            if (renderer instanceof PlayerRenderer playerRenderer) {
                helper.register(new SheathFeature(playerRenderer));
            }
        });
    }
}
