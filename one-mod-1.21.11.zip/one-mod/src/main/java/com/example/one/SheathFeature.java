package com.example.one;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/**
 * Shows a knife on the player's right hip when it isn't in the main hand.
 * Visual only. Built against the 1.21.x render layer API. Verify the render signature first.
 */
public class SheathFeature extends RenderLayer<AbstractClientPlayer, PlayerModel> {

    public SheathFeature(RenderLayerParent<AbstractClientPlayer, PlayerModel> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (!OneMod.CONFIG.sheath || player.isInvisible()) return;

        ItemStack held = player.getMainHandItem();
        ItemStack knife = KnifeAnimator.isKnife(held) ? new ItemStack(held.getItem()) : new ItemStack(KnifeItems.KATANA);

        pose.pushPose();
        getParentModel().body.translateAndRotate(pose);
        pose.translate(0.45, 0.9, 0.05);
        pose.mulPose(Axis.ZP.rotationDegrees(-30f));
        pose.scale(0.5f, 0.5f, 0.5f);
        Minecraft.getInstance().getItemModelResolver()
                .updateForTopItem(new ItemStackRenderState(), knife, ItemDisplayContext.THIRD_PERSON_RIGHT_HAND,
                        player.level(), player, 0);
        pose.popPose();
    }
}
