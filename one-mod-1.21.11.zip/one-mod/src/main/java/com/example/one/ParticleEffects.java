package com.example.one;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Visual-only particles: jump rings, sprint trails, fireflies, shockwaves. */
public final class ParticleEffects {
    private static final int PURPLE = 0xB56CFF;
    private static final int PINK = 0xFF7AD9;
    private static final int[] FIREFLY_COLORS = {0x7CF5FF, 0xFFD36B, 0xFF7AD9, 0x9DFF8A, 0xB56CFF};

    private static boolean wasOnGround = true;
    private static final List<Shockwave> waves = new ArrayList<>();

    private ParticleEffects() {}

    private static final class Shockwave {
        final Vec3 center;
        double radius = 0.5;
        int age = 0;
        Shockwave(Vec3 c) { this.center = c; }
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            ClientLevel level = mc.level;
            Player player = mc.player;
            if (level == null || player == null || mc.isPaused()) return;

            tickJumpRings(level, player);
            tickTrails(level, player);
            tickFireflies(level, player);
            tickShockwaves(level);
        });
    }

    private static void tickJumpRings(ClientLevel level, Player p) {
        boolean onGround = p.onGround();
        if (OneMod.CONFIG.jumpRings && onGround != wasOnGround) {
            spawnRing(level, p.position(), PURPLE, 0.9, 24);
            spawnRing(level, p.position(), PINK, 0.55, 16);
        }
        wasOnGround = onGround;
    }

    private static void tickTrails(ClientLevel level, Player p) {
        if (!OneMod.CONFIG.trails || !p.isSprinting() || !p.onGround()) return;
        Vec3 back = p.position().subtract(p.getLookAngle().scale(0.6));
        for (int i = 0; i < 2; i++) {
            level.addParticle(new DustParticleOptions(PURPLE, 0.8f),
                    back.x + rnd(-0.2, 0.2), back.y + rnd(0.1, 0.9), back.z + rnd(-0.2, 0.2),
                    0, 0.02, 0);
        }
    }

    private static void tickFireflies(ClientLevel level, Player p) {
        if (!OneMod.CONFIG.fireflies) return;
        if (ThreadLocalRandom.current().nextInt(4) != 0) return;
        Vec3 c = p.position();
        int color = FIREFLY_COLORS[ThreadLocalRandom.current().nextInt(FIREFLY_COLORS.length)];
        level.addParticle(new DustParticleOptions(color, 0.5f),
                c.x + rnd(-14, 14), c.y + rnd(0.5, 6), c.z + rnd(-14, 14),
                rnd(-0.05, 0.05), rnd(-0.01, 0.03), rnd(-0.05, 0.05));
    }

    /** Call when you want a shockwave (e.g. from a future trigger). */
    public static void spawnShockwave(Vec3 at) {
        if (OneMod.CONFIG.shockwaves) waves.add(new Shockwave(at));
    }

    private static void tickShockwaves(ClientLevel level) {
        Iterator<Shockwave> it = waves.iterator();
        while (it.hasNext()) {
            Shockwave w = it.next();
            w.radius += 0.25;
            w.age++;
            spawnRing(level, w.center, PURPLE, w.radius, Math.max(12, (int) (w.radius * 10)));
            if (w.age > 30) it.remove();
        }
    }

    private static void spawnRing(ClientLevel level, Vec3 c, int color, double radius, int points) {
        for (int i = 0; i < points; i++) {
            double a = (Math.PI * 2 / points) * i;
            level.addParticle(new DustParticleOptions(color, 0.9f),
                    c.x + Math.cos(a) * radius, c.y + 0.05, c.z + Math.sin(a) * radius,
                    0, 0, 0);
        }
    }

    private static double rnd(double lo, double hi) {
        return ThreadLocalRandom.current().nextDouble(lo, hi);
    }
}
