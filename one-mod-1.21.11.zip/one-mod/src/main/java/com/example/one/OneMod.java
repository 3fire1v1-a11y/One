package com.example.one;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.ModInitializer;

public class OneMod implements ModInitializer, ClientModInitializer {
    public static final String MOD_ID = "one";
    public static final OneConfig CONFIG = new OneConfig();

    @Override
    public void onInitialize() {
        CONFIG.load();
        KnifeItems.register();
    }

    @Override
    public void onInitializeClient() {
        HudPill.register();
        ParticleEffects.register();
        SkyWeatherEffects.register();
        KnifeItems.registerColors();
        KnifeAnimator.register();
        KnifeConfigScreen.registerKey();
        VisualToggleScreen.registerKey();
        SheathRegistration.register();
    }
}
