package com.example.one;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Sky and weather using particles only, so no rendering mixins.
 * Sky: a drifting aurora curtain high overhead plus shooting stars.
 * Weather: a blizzard of snow blowing across the player.
 * This is an approximation, not a real shader.
 */
public final class SkyWeatherEffects {
    private static final int[] AURORA = {0xB56CFF, 0x7CF5FF, 0x9DFF8A, 0xFF7AD9};
    private static final List<Star> stars = new ArrayList<>();
    private static int ticks = 0;

    private SkyWeatherEffects() {}

    private static final class Star {
        Vec3 pos;
        final Vec3 vel;
        int life = 12;
        Star(Vec3 pos, Vec3 vel) { this.pos = pos; this.vel = vel; }
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            ClientLevel level = mc.level;
            Player player = mc.player;
            if (level == null || player == null || mc.isPaused()) return;
            ticks++;

            if (OneMod.CONFIG.sky) {
                tickAurora(level, player);
                tickShootingStars(level, player);
            }
            if (OneMod.CONFIG.weather) {
                tickBlizzard(level, player);
            }
        });
    }

    private static void tickAurora(ClientLevel level, Player p) {
        if (ticks % 2 != 0) return;
        Vec3 c = p.position();
        int color = AURORA[(ticks / 40) % AURORA.length];
        for (int i = 0; i < 6; i++) {
            double a = rnd(0, Math.PI * 2);
            double r = rnd(40, 60);
            double h = 45 + Math.sin(a * 3 + ticks * 0.05) * 6;
            level.addParticle(new DustParticleOptions(color, 1.2f),
                    c.x + Math.cos(a) * r, c.y + h, c.z + Math.sin(a) * r,
                    0, 0, 0);
        }
    }

    private static void tickShootingStars(ClientLevel level, Player p) {
        if (ticks % 90 == 0 && ThreadLocalRandom.current().nextInt(2) == 0) {
            Vec3 c = p.position();
            Vec3 start = new Vec3(c.x + rnd(-40, 40), c.y + rnd(35, 55), c.z + rnd(-40, 40));
            stars.add(new Star(start, new Vec3(rnd(-1.2, 1.2), rnd(-0.9, -0.5), rnd(-1.2, 1.2))));
        }
        Iterator<Star> it = stars.iterator();
        while (it.hasNext()) {
            Star s = it.next();
            level.addParticle(ParticleTypes.END_ROD, s.pos.x, s.pos.y, s.pos.z, 0, 0, 0);
            s.pos = s.pos.add(s.vel);
            if (--s.life <= 0) it.remove();
        }
    }

    private static void tickBlizzard(ClientLevel level, Player p) {
        Vec3 c = p.position();
        for (int i = 0; i < 10; i++) {
            level.addParticle(ParticleTypes.SNOWFLAKE,
                    c.x + rnd(-16, 16), c.y + rnd(2, 10), c.z + rnd(-16, 16),
                    0.25, -0.15, 0.05);
        }
    }

    private static double rnd(double lo, double hi) {
        return ThreadLocalRandom.current().nextDouble(lo, hi);
    }
}
