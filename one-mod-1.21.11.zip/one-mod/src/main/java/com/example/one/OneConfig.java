package com.example.one;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Toggles, knife colors (ARGB), and animation speed. Saved to config/one.json. */
public class OneConfig {
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("one.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public boolean hudPill = true;
    public boolean jumpRings = true;
    public boolean trails = true;
    public boolean fireflies = true;
    public boolean shockwaves = true;
    public boolean sky = true;       // aurora and shooting stars (toggle with L)
    public boolean weather = true;   // blizzard (toggle with L)
    public boolean sheath = true;    // knife on the hip when not held

    // Knife customization. Tint 0 = blade, 1 = handle, 2 = accent.
    public int knifeBlade  = 0xFFE6DDFF;
    public int knifeHandle = 0xFF2B1B4A;
    public int knifeAccent = 0xFFFF7AD9;

    /** Multiplier for flip and inspect speed. 0.25 to 3.0. */
    public float knifeAnimSpeed = 1.0f;

    public void load() {
        try {
            if (!Files.exists(PATH)) return;
            OneConfig saved = GSON.fromJson(Files.readString(PATH), OneConfig.class);
            if (saved == null) return;
            hudPill = saved.hudPill;
            jumpRings = saved.jumpRings;
            trails = saved.trails;
            fireflies = saved.fireflies;
            shockwaves = saved.shockwaves;
            sky = saved.sky;
            weather = saved.weather;
            sheath = saved.sheath;
            knifeBlade = saved.knifeBlade;
            knifeHandle = saved.knifeHandle;
            knifeAccent = saved.knifeAccent;
            knifeAnimSpeed = Math.max(0.25f, Math.min(3.0f, saved.knifeAnimSpeed));
        } catch (Exception e) {
            // Bad or missing file: keep defaults
        }
    }

    public void save() {
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(this));
        } catch (Exception e) {
            // Could not write: settings still apply for this session
        }
    }
}
