package com.example.one;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

/** Quick on/off switches for the aurora (plus shooting stars) and the blizzard. Press L in game. */
public class VisualToggleScreen extends Screen {
    private static KeyMapping openKey;

    private final Screen parent;

    public VisualToggleScreen(Screen parent) {
        super(Component.literal("One: Visual Toggles"));
        this.parent = parent;
    }

    public static void registerKey() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(OneMod.MOD_ID, "keys"));
        openKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.one.visuals", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_L, category));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.consumeClick()) {
                if (mc.screen == null) mc.setScreen(new VisualToggleScreen(null));
            }
        });
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 3;

        addRenderableWidget(Button.builder(auroraLabel(), b -> {
            OneMod.CONFIG.sky = !OneMod.CONFIG.sky;
            OneMod.CONFIG.save();
            b.setMessage(auroraLabel());
        }).bounds(cx - 100, y, 200, 20).build());

        addRenderableWidget(Button.builder(blizzardLabel(), b -> {
            OneMod.CONFIG.weather = !OneMod.CONFIG.weather;
            OneMod.CONFIG.save();
            b.setMessage(blizzardLabel());
        }).bounds(cx - 100, y + 30, 200, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(cx - 100, y + 60, 200, 20).build());
    }

    private static Component auroraLabel() {
        return Component.literal("Aurora and stars: " + (OneMod.CONFIG.sky ? "ON" : "OFF"));
    }

    private static Component blizzardLabel() {
        return Component.literal("Blizzard: " + (OneMod.CONFIG.weather ? "ON" : "OFF"));
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        super.render(gfx, mouseX, mouseY, partialTick);
        gfx.drawCenteredString(this.font, this.title, this.width / 2, this.height / 3 - 25, 0xFFFFFFFF);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
